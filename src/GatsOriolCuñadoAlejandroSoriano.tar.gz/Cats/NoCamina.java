package Cats;

/**
 * Created by 48089748z on 01/03/16.
 */
public class NoCamina implements Caminable
{
    @Override
    public void diguemSiCamina() {
        System.out.println("No camina");
    }
}
