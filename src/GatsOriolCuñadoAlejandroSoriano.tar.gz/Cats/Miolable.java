package Cats;

/**
 * Created by 48089748z on 01/03/16.
 */
public interface Miolable
{
    void miau();
}
