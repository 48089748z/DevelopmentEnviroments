package Cats;

/**
 * Created by 48089748z on 01/03/16.
 */
public interface Caminable
{
    void diguemSiCamina();
}
