package Cats;

/**
 * Created by 48089748z on 01/03/16.
 */
public class SenseMiau implements Miolable
{
    public void miau()
    {
        System.out.println("Sense Miau");
    }
}
