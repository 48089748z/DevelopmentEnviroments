package Game;

/**
 * Created by 48089748z on 08/03/16.
 */
public class DragonScimitar implements Weapon
{

    @Override
    public void whatWeaponHeWearing() {
        System.out.println("\nWeapon: Dragon Scimitar");

    }
}
