package Game;

public class StaffoftheDead implements Weapon
{
    @Override
    public void whatWeaponHeWearing()
    {
        System.out.println("\nWeapon: Staff of the Dead");
    }
}
