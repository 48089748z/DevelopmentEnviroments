package Game;

/**
 * Created by 48089748z on 08/03/16.
 */
public interface Weapon
{
    void useWeapon();
}
